#ifndef THEDATE 
#define THEDATE "<23-Jun-1999 12:17:34><MDT>"
#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>       /* needed by open, may need -D_HPUX_SOURCE in c89 */

#include "io.h"


/* * * * * Comments on ioTape routines * * * * * * * * * 
    ioTape
    ioTapeOpen
    ioTapeStatus80
 * These routines are for reading/postioning 9-track mag tape and DDS (DAT) 
 * tapes on Sun/Solaris systems. Testing for DDS tapes was minimal.
 *
 * This program works better on HPs where set-marks are recognized!!
 *
 * These io routines work best with Berkeley-no-rewind tape-device files
 * (use lssf device-file-name to check yours out).
 * This was written by Robert Hueftle, NOAA/ERL/NSSL/MRD,
 * for an HP9000/827.  "<23-Jun-1999 12:17:34><MDT>"
 * Note: whenever one of these routines is called by fortran program, instead of
 * passing string, it is suggested to pass by reference an integer array
 * which is in equivalence to the string so the problem of Fortran
 * passing the string's length as a value is not encountered.
 */


/*****************************  ioTape  *******************************
 Perform IO on an  9-track and DDS("DAT") tape drive (including read/writes)
 Entry conditions:
 * func=0 read one record from tape
 *     =1 write one record to tape
 *     =2 write an EOF mark(s)
 *     =3 backspace record(s)
 *     =4 skip forward record(s)
 *     =5 backskip file(s) (position before most previous EOF)
 *     =6 skip forward file(s)
 *     =7 rewind
 *     =8 rewind and take off line
 *     =9 get tape status
 *     =10 DDS only, seek to end-of-data
 * buffPt: points to character buffer, N.A. except for read & write rec. 
 * numToDo: for read = bytes to try to read
 *          for write = bytes to write
 *          for write EOF = EOF's to write
 *          for positioning commands = number of times to do respective
 *              positioning
 * fdTape: file descriptor from the open of the device file for the tape unit.
 Exit conditions, based on value returned by ioTape:
 *  for read/write calls:
 *      if =0, then no bytes were read/written
 *      if >0, then = number of bytes that were read/written
 *      if <0, then see below for special status condtion.  Note that it
 *             is possible for a read/write to be done even though an
 *             EOT was sensed, in which case the status flag for EOT
 *             will have higher importance.
 *  for other calls:
 *      if =0, then the operation was successfull.
 *      if <0, then special status condition.
 *  special status condtions:
 *      if = -1, undefined error
 *         = -2, End-Of-File (!! not reported on writing EOF or skip EOF's!!)
 *         = -3, End-Of-Tape read
 *         = -4, drive door is open
 *         = -5, drive is not on line
 *         = -6, write protected (!!only reported on write and status commands!)
 *         = -7, BOT (not reported on rewind commands)
 *         = -8, illegal request 
 *         = -10,DDS end-of-data encountered (!!not reported on seek endofdata)
*****************************************************************************/
int ioTape (int func, char *buffPt,int numToDo,int fdTape)

{ 
#include <sys/types.h>
#include <sys/mtio.h>
    struct mtop mtop;            /* defined in sys/mtio.h: for op calls */
    struct mtget mtget;          /* defined in sys/mtio.h: for status calls */

    const int   OKoperation = 0; /*used when IO operation (except r/w) went OK*/
    const int   undefined_err=-1;/*undefined error (possibly parity error) */
    const int   end_file= -2;    /*end of file sensed */
    const int   end_tape= -3;    /*end of tape sensed */
    const int   door_open=-4;    /*drive door open */
    const int   off_line=-5;     /*drive is off line */
    const int   write_protected=-6;/*tape is write protected */
    const int   begin_tape = -7; /* beginning of tape sensed */
    const int   illegalReq = -8; /* used when bad parameters passed to module */
    const int   end_data = -10;  /* DDS: end of data sensed */
    int         recLen; 
    int         returnVal;        /* return value from function calls */

    switch (func)
    {
    case 0:
/* read a record */
	if (numToDo < 1)
	    return illegalReq;
        recLen = read (fdTape, buffPt, numToDo);
	if (recLen > 0)
            return (recLen);
	break;
    case 1:
/* write a record */
	if (numToDo < 1)
	    return illegalReq;
        recLen = write (fdTape, buffPt, numToDo);
	if (recLen == numToDo)
            return (recLen);
	break;
    case 2:
/* write EOF(s) */
	if (numToDo < 1)
	    return illegalReq;
        mtop.mt_op = MTWEOF;
        mtop.mt_count = numToDo;
        returnVal = ioctl(fdTape, MTIOCTOP, &mtop);
        if (returnVal != -1)
	    return OKoperation;
	break;
    case 3:
/* backspace record(s) */
	if (numToDo < 1)
	    return illegalReq;
        mtop.mt_op = MTBSR;
        mtop.mt_count = numToDo;
        returnVal = ioctl(fdTape, MTIOCTOP, &mtop);
        if (returnVal != -1)
	    return OKoperation;
	break;
    case 4:
/* skip forward record(s) */
	if (numToDo < 1)
	    return illegalReq;
        mtop.mt_op = MTFSR;
        mtop.mt_count = numToDo;
        returnVal = ioctl(fdTape, MTIOCTOP, &mtop);
        if (returnVal != -1)
	    return OKoperation;
	break;
    case 5:
/* backskip file(s) */
	if (numToDo < 1)
	    return illegalReq;
        mtop.mt_op = MTBSF;
        mtop.mt_count = numToDo;
        returnVal = ioctl(fdTape, MTIOCTOP, &mtop);
        if (returnVal != -1)
	    return 0;            /* ok operation */
	break;
    case 6:
/* forward skip file(s) */
	if (numToDo < 1)
	    return illegalReq;
        mtop.mt_op = MTFSF;
        mtop.mt_count = numToDo;
        returnVal = ioctl(fdTape, MTIOCTOP, &mtop);
        if (returnVal != -1)
	    return 0;            /* ok operation */
	break;
    case 7:
/* rewind */
        mtop.mt_op = MTREW;
        mtop.mt_count = 1;
        returnVal = ioctl(fdTape, MTIOCTOP, &mtop);
        if (returnVal != -1)
	    return OKoperation;
	break;
    case 8:
/* rewind and put offline */
        mtop.mt_op = MTOFFL;
        mtop.mt_count = 1;
        returnVal = ioctl(fdTape, MTIOCTOP, &mtop);
        if (returnVal != -1)
	    return OKoperation;
	break;
    case 9:
/* just get status */
	break;
    case 10:
/* DDS only: seek to end-of-data, but 8mm to end-of-medium */
        mtop.mt_op = MTEOM;
        mtop.mt_count = 1;
        returnVal = ioctl(fdTape, MTIOCTOP, &mtop);
        if (returnVal != -1)
	    return OKoperation;
	break;
    case 11:
/* DDS only: write setmark(s) */
	return illegalReq;
/*    Can't do on Solaris 
	if (numToDo < 1)
	    return illegalReq;
        mtop.mt_op = MTWSS;
        mtop.mt_count = numToDo;
        returnVal = ioctl(fdTape, MTIOCTOP, &mtop);
        if (returnVal != -1)
	    return OKoperation;
	break;
 */
    case 12:
/* DDS only: space back setmark(s) */
	return illegalReq;
/*    Can't do on Solaris 
	if (numToDo < 1)
	    return illegalReq;
        mtop.mt_op = MTBSS;
        mtop.mt_count = numToDo;
        returnVal = ioctl(fdTape, MTIOCTOP, &mtop);
        if (returnVal != -1)
	    return OKoperation;
	break;
 */
    case 13:
/* DDS only: space forward setmark(s) */
	return illegalReq;
/*    Can't do on Solaris 
        if (numToDo < 1)
	    return illegalReq;
        mtop.mt_op = MTFSS;
        mtop.mt_count = numToDo;
        returnVal = ioctl(fdTape, MTIOCTOP, &mtop);
        if (returnVal != -1)
	    return OKoperation;
	break;
 */
    default:
/* Bad parameter passed for function */
	return illegalReq;
    } /* end of switch (func) */

/* At this point we need to find out why IO operation had problem (or
   if func == 9, just to get status)
   Try to test for more "severe" status conditions before less "severe".
 */
    ioctl(fdTape, MTIOCGET, &mtget);
/*
 Need to do something!!

    if (GMT_EOT(mtget.mt_dsreg)) 
	return end_tape;
    if ((func != 1)&&(func !=5)&&(func != 6)&&GMT_EOF(mtget.mt_dsreg)) 
	return end_file; /* don't return as error for eof ops (write,skip)*
    if ((func != 11)&&(func !=12)&&(func != 13)&&GMT_SM(mtget.mt_dsreg)) 
	return set_mark; /* don't return as error for setMark ops (write,skip)*
    if (GMT_DR_OPEN(mtget.mt_dsreg)) 
	return door_open;
    if (! GMT_ONLINE(mtget.mt_dsreg)) 
	return off_line;
    if (((func == 1) || (func ==2)||(func ==11))&& GMT_WR_PROT(mtget.mt_dsreg)) 
	return write_protected; /*only see as error for write ops (rec,eof,SM)*
    if ((func !=7) && (func !=8)&& GMT_BOT(mtget.mt_dsreg)) 
	return begin_tape; /* don't return as error for rewind commands *
    if ((func !=10)&& GMT_EOD(mtget.mt_dsreg)) 
	return end_data; /* don't return as error for go-to-end command *
    if (func !=9) 
        return undefined_err; /* don't know what error is *
    return OKoperation;       /* could't find any special status to report *

 */
    if ((func != 1)&&(func !=5)&&(func != 6)&&(mtget.mt_erreg==18)) 
	return end_file; /* don't return as error for eof ops (write,skip)*/
    if ((func != 7)&&(func !=8)&&(mtget.mt_erreg==21)) 
	return begin_tape; /* don't return as error for rewind commands */
    if ((func !=10)&& (mtget.mt_erreg==19))
	return end_data; /* don't return as error for go-to-end command */

    fprintf(stderr,"mtget.mt_dsreg = %d, mtget.mt_erreg = %d \n"
              "Lack of available Sun-Solaris documentation :~( \n",
            (int) mtget.mt_dsreg ,(int)  mtget.mt_erreg );
  return undefined_err;
} /* ioTape ends */

#ifndef THEDATE 
#define THEDATE "<23-Jun-1999 12:17:34><MDT>"
#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>       /* needed by open, may need -D_HPUX_SOURCE in c89 */


/* * * * * Comments on ioTape routines * * * * * * * * * 
    ioTape
    ioTapeOpen
    ioTapeStatus80
 * These routines are for reading/postioning 9-track mag tape and DDS (DAT) 
 * tapes on HP systems. Testing for DDS tapes was minimal.
 * These io routines work best with Berkeley-no-rewind tape-device files
 * (use lssf device-file-name to check yours out).
 * This was written by Robert Hueftle, NOAA/ERL/NSSL/MRD,
 * for an HP9000/827.  "<23-Jun-1999 12:17:34><MDT>"
 * When you run c89 you may need to have "-D_HPUX_SOURCE" 
 * Note: whenever one of these routines is called by fortran program, instead of
 * passing string, it is suggested to pass by reference an integer array
 * which is in equivalence to the string so the problem of Fortran
 * passing the string's length as a value is not encountered.
 */

/*
 *  ioTapeOpen 
 *  open up device file name with either ReadOnly or ReadWrite.
 *  Input conditions:
 *     openMode
 *            =1 for ReadOnly
 *            =0 for ReadWrite
 *     tapeName is device file for tape drive
 *  Return value:
 *     file descriptor if successful open
 *     else -1 if no success or if openMode is out-of-range.
 */
int ioTapeOpen(char *tapeName,int openMode)
{
    if (openMode == 1)
/* open tape dev file with non-ansi open */
        return (open (tapeName,O_RDONLY,0));
    else if (openMode == 0)
	return ( open (tapeName,O_RDWR,0));
    return (-1);          /* error return */
} /* ioTapeOpen ends */
#ifndef THEDATE 
#define THEDATE "<23-Jun-1999 12:17:34><MDT>"
#endif
/*
 *  ioTapeStatus80
 *  fill message with characters describing error status as returned
 *  from module ioTapeStatus: all are <=0.
 *  The messages, including '\0', are 80 characters or less.
 */
void ioTapeStatus80(int status, char message[])
{
    switch (status)
    {
    case 0:
	strcpy(message,"0: IO tape status successful");
	break;
    case -1:
	strcpy(message,
"-1: undefined error (parity perhaps or wrong density or compression).");
	break;
    case -2:
	strcpy(message,"-2: End of File.");
	break;
    case -3:
	strcpy(message,"-3: End of Tape sensed.");
	break;
    case -4:
	strcpy(message,"-4: Drive Door is Open.");
	break;
    case -5:
	strcpy(message,"-5: Tape Drive is not on line.");
	break;
    case -6:
	strcpy(message,"-6: Drive is Write Protected. ");
	break;
    case -7:
	strcpy(message,"-7: Beginning of tape sensed.");
	break;
    case -8:
	strcpy(message,"-8: Illegal request to ioTape module.");
	break;
    case -9:
	strcpy(message,"-9: DDS set mark encountered.");
	break;
    case -10:
	strcpy(message,"-10: DDS end-of-data encountered. ");
	break;
    default:
	sprintf(message,"%d: Not recognized as status condition from ioTape!"
	     , status);
	break;
    }  /* end of switch (status) */
    return;
}  /* ioTapeStatus80 ends */
