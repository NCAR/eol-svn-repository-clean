#ifndef THEDATE
#define THEDATE "<23-Jun-1999 12:16:51><MDT>"
#endif

/*
 * io.h: defines for io.c.
 *
 */

#ifndef IO_HEADER
#define IO_HEADER


#define     NO_FUNCTION    -100 /* not be a function acceptable to ioTape*/
#define     EOFstatus  -2   /* from ioTape */

/* function prototypes */

int ioTape (int , char *,int,int );
int ioTapeOpen(char *tapeName,int openMode);
void ioTapeStatus80(int, char []);

#endif /* End of "#ifndef IO_HEADER" */
/*
 * Don't add lines after this.
 */
