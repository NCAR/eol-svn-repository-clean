#define THEDATE "<25-Jul-2000 09:38:21><MDT>"

/* p3tape_disk: copy from p3 radar tape to disk files, in one of
 *       several ways.
 *       See character string runStringArgUse for details.
 * programming:
 *       Robert Hueftle, NOAA/NSSL/MRBoulder at NCAR/MMM.
 *
 * Note: array static char logBuffer[LOGBUFFER_LEN] 
 *   is filled but currently not written out.
 *
 */

#include <ctype.h>
#include <fcntl.h>   
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#include "io.h"

#define  TRUE 1        
#define  FALSE 0
#define  HEADER_LEN  2048  /* buffer length of P3 radar header record */
#define  MAX_REC_LEN  32768 /*  maximum buffer length */
#define  LOGBUFFER_LEN 2 /* use 32768 or bigger if you want to read into logBuffer */
#define  TEMPSTRING_LEN 2048
#define  REALTIME_LEN 33  /* length to hold eal time strings */
#define  DEF_UNKNOWN_ERR_LIMIT 0 /* default limit on unknown errors in reading*/

#define FIRST_OPEN_FILE  TRUE 
#define FILE_ALREADY_OPEN FALSE


enum fileMethod {FILES1_1=0,QUARTER_HOUR,TIME_SEGS,FIVE_MINUTES,ONE_MINUTE};
enum timeFileReading {T_ERROR=0,T_OK_DATE,T_NO_MORE};
enum typeP3 {TYPE_ERROR=0,LENGTH_ERROR,DATE_ERROR,
     HEADER_REC,LF_REC,TA_REC};

/*
 * Defines, etc., used by modules normally in librah_C, but which
 * are included in this source code for independence.
 */

/******************************  Date ****************************************
 * Stores information pertinent to dates
 * Use short int instead of unsigned char: may catch errors in dates.
 *****************************************************************************/
typedef struct _NxDate
{ short int year;                      /* four digit year  */
  short int month;                     /* month            */
  short int day;                       /* day              */
} NxDate;

/******************************  Time  ***************************************
 * Stores information pertinent to times
 * Use short int instead of unsigned char: may catch errors in times.
 *****************************************************************************/
typedef struct _NxTime
{ short int hour;                      /* hour             */
  short int minute;                    /* minute           */
  short int second;                    /* second           */
  short int milliSecond;               /* milli second     */
} NxTime;

#define NX_YEAR_CUTOFF 78  /* 78-99 for 1978-1999, 0-77 for 2000-2077 */
#define NX_FATAL 1

/* function prototypes */
int     diskWrite(char buffer[], int bytesToWrite,FILE * fp,char fileName[]);
int     mallocateAddString(char ** stringPtr, char * addString);
void    NxAbort (int abortNumber,char * module,char * message);
void    NxChangeTime (NxDate *date,NxTime *time,short int change);
int     NxFullYear (int year);
short int NxOkTime (NxDate date, NxTime time);
short int NxTimeBefore (NxDate date1, NxTime time1, NxDate date2, NxTime time2);
void    packSInt (char *bufpt,short int SInt[],int count, int swap);
int     readTimeFile(int newFile,char timeFile[],
                 NxDate * datePtr,NxTime * timePtr);
char    stdY_N (char *question,char the_default);
char  * strtoupper (char *string);
int     typeDateTime(char ioBuffer[],int recLen,NxDate * datePtr,
           NxTime * timePtr);

/*
 * global variables
 */

int DEBUG=FALSE;   /* TRUE for printing debug statements; can be overridden
		     if user sets UNIX global variable DEBUG to "TRUE" or
		     "FALSE" */
main(int argc, char*argv[])
{
	char *sourcedate;
	char *prog = argv[0];          /* program name */
	char ident[] = "@(#) " THEDATE;
	/* ident is for program "what" */
	char *tapeRead;                /*get name from run string*/
	char *flightID;                /*get name from run string*/
	char *timeFile;                /*get name from run string*/
	char runStringArgUse [] = 
 "dev_file_src flightID file_breakdown numb_files [max_errs] [consecEOFs]\n"
 "   1st arg: dev_file_src: device file name for tape to read\n"
 "   2nd arg: flightID: flightID (will be used to make a subdirectory)\n"
 "   3rd arg: file_breakdown: one of the following \n"
 "                   \"f\" for 1 disk file for each tape file \n"
 "                   \"q\" or \"15\" for new disk file every quarter hour \n"
 "                   \"5\" for new disk file every 5 minutes \n"
 "                   \"1\" for new disk file every 1 minute \n"
 "                   timeFile, where each line of timeFile contains the \n"
 "                           date/time for each new disk file, where the \n"
 "                           date/time line would look like\n"
 "                           \"1999/03/31 041200\", i.e., YYYY/MM/DD HHMMSS\n"
 "   4th arg: numb_files: number of tape files to read \n"
 "            (This can be > than number on tape if true number unknown).\n"
 "   5th arg (optional) max_errs: maximum read errors (probably parity)\n"
 "            that can be read in a file before aborting.\n"
 "   6th arg (optional) consecEOFs: = \"consecEOFs\" to keep consecutive\n"
 "                   EOFs; default is to ignore consecutive EOFs\n"
 "                   i.e., 3 consecutive EOFs are seen as one EOF\n"
 "                   (these consecutive EOFs would reappear when\n"
 "                   \"p3disk_tape\" is used to recreate the tape\n"
 "                   from the disk files)\n"
 "\n"
 "Special Note: the device file for the tape drive should\n"
 "    be Berkeley no-rewind.  \n";
 
	char headerRec[HEADER_LEN];
	static char ioBuffer [MAX_REC_LEN];
	static char logBuffer[LOGBUFFER_LEN];  /* buffer for keeping track of
					   records copied in each file,
					   initially all zeroes*/
	char realTimeStart[REALTIME_LEN];
	char realTimeEnd[REALTIME_LEN];
	char * tempCharPtr;          /* temporary pointer */
	char tempString [TEMPSTRING_LEN]; /* temporary string buffer */
	char unixCommand [TEMPSTRING_LEN];
	char * nameList=NULL;     /* point to name of disk file with list
				     of the p3tape_disk files that are written*/
	char * nameOut=NULL;      /* point to name of output disk file */
	char * nameOutOld=NULL;   /* point to old name of output disk file */

	const int ReadOnly = 1;   /* for ioTapeOpen open mode to ReadOnly */
	const int ReadRec = 0;    /* for ioTape read function */
	const int StatusEOF= -2; /* for ioTape status for EOF read */
	const int StatusSET= -9; /* for ioTape status for Set-mark read */
	const int StatusUnknown= -1; /* for ioTape status for unknown error,
					which is often (usually??) parity */
	int  addMinutes;          /* for changing a date/time */
	int  biggestRecLen;       /* most bytes read/written */
	int  consecEOFs=FALSE;    /* = TRUE or FALSE */
	int  emptyFilesTotal;     /* count of Total EOF's skipped because they
				     were for empty files  */
	int  errorRecordsSkipped=0;/* count of "error" records NOT copied */
	int  extraHeadersCopied=0; /* count of extra header records copied */
	int  fileDesTapeR;        /* file descriptor for tapeRead */
        int  filesToCopy;         /* files to copy */
	int  filesReadTotal;      /* count of Total files read: will be
				     incremented when EOF read*/
	int  filesCopiedTotal;    /* count of disk files written;
				     incremented once another file is opened
				     for writing (can be
				     more OR less than filesReadTotal) */
        int  fixedMinutes;        /* length of fixed time period; 
				     used when method = QUARTER_HOUR,
				     FIVE_MINUTES, or ONE_MINUTE */
	int  headerRecRead = FALSE; /* TRUE if header record read in headerRec*/
	int  keepReadingFile;     /* = TRUE or FALSE */
	int  keepReadingTape;     /* = TRUE or FALSE */
	int  logBufferAdd;        /* bytes to add to logBuffer */
	static int  logBufferEnd;        /* index of NULL (end) in logBuffer,
				     should be < LOGBUFFER_LEN */
	int  method;              /* should be one of enum fileMethod values */
	int  moreBoundaries = FALSE; /* TRUE if timeFile open and no EOF */
	int  recordsCopied;       /* count of records copied for
				     current file being written (which
				     may be different than the file being
				     read)*/
	int  recordsCopiedTotal;  /* count of Total records
				     copied (include copying extra header
				     records)*/
	int  recordsRead;         /* count of records read for
				     current file being read  */
	int  recordsReadTotal;    /* count of total records read */
	int  returnVal;           /* temp return value from function calls */
	int  recLen;	          /* number of bytes read/written */
	int  recLen2;	          /* number of bytes read/written */
	int  recType;	          /* value from enum typeP3, record type */
        int  setsSeen;            /* count of set-marks seen */
	int  status;              /* temp return value from function calls */
	int  statusEOF;           /* temp return value from EOF calls */
	int  systemStatus;        /* temp return value from Unix  calls */
        int  timeStatus;          /* should = one of enum timeFileReading*/

        int  unknownErr;           /* counter of unknown read errors in file */
	int  unknownErrLimit =
	     DEF_UNKNOWN_ERR_LIMIT; /* limit on number of unknown tape errors
				       on reading (suspected to be parity
				       errors) a file before stopping the
				       reading */
	long double  bytesReadTotal; /*long double count of Total bytes read*/
	long double  bytesCopiedTotal;
		    /*long double count of Total bytes copied, excluding
		      the logical record length flags (which are 4bytes/flag,
		      and 2 flags per logical record (including logical EOF))*/

        time_t *timePt;
	time_t timeInternal;

        FILE  *fpList = NULL;/*file pointer for writing names of disk files */
        FILE  *fpOut  = NULL;/*file pointer for writing out the disk files */
        FILE  *fpTime = NULL;/*file pointer for reading the time file*/

/*  boundaryDate/boundaryTime are used when method = TIME_SEGS*/
        NxDate boundaryDate;       /* date for time segment boundary */
        NxTime boundaryTime;       /* time for time segment boundary */
/*  endFixedTimePeriodDate/endFixedTimePeriodTime are used when method
   = QUARTER_HOUR, FIVE_MINUTES, or ONE_MINUTE */
        NxDate endFixedTimePeriodDate; /* date for end of fixed time period */
        NxTime endFixedTimePeriodTime; /* time for end of fixed time period */
        NxDate thisDate;           /* date most recently read from p3 tape */
        NxTime thisTime;           /* time most recently read from p3 tape */

	sourcedate = THEDATE; 	/* point to source code update */

	if ((argc > 7)||(argc < 5))	/* not 4-6 arguments, error */
	    {
	    fprintf(stderr, "\nError on evoking %s!  "
		"Use run-string like\n%s %s\n",prog,prog,
		runStringArgUse);
	    exit(1);
	    }
        if (argc == 7)     /* arg 7(6-th run arg): for enabling "keeping"
			      consecutive EOFs */
            {
            strncpy (tempString,argv[6],TEMPSTRING_LEN -1);
            strtoupper (tempString);
            if (strcmp(tempString,"CONSECEOFS") &&
                (tempString[0] != '\0'))
                {
                fprintf(stderr,"\n 6th run string arg bad!!\n");
                fprintf(stderr, "\nError on evoking %s!  "
                    "Use run-string like\n%s %s\n",prog,prog,
                    runStringArgUse);
                exit (1);
                }
            consecEOFs = (! strcmp(tempString,"CONSECEOFS"))? TRUE:FALSE;
            }

	if ((argc >= 6) && (strcmp(argv[5],"")))/* arg 6(5-th run arg):
						     max read errors*/
	    {
	    if ((sscanf(argv[5],"%d",&unknownErrLimit) != 1) ||
		(unknownErrLimit <0))
		{
		fprintf(stderr, "\n error on reading integer (max read errs)"
		    "in run-string arg \"%s\"!!\n",argv[5]);
		exit(1);
		}
	    }

/* 
 * Run string arguments 1-4 should be there, so grab them.
 */
        tapeRead = argv[1];
        flightID = argv[2];
        strncpy (tempString,argv[3],TEMPSTRING_LEN -1);
        strtoupper (tempString);
	timeFile = "";
	fixedMinutes = 0;  /* in case not used */
        if (strcmp(tempString,"F") == 0)
	    method = FILES1_1; 
        else if ( (strcmp(tempString,"Q") == 0) ||
                  (strcmp(tempString,"15") == 0))  /* in case user put 15 */
	    {
	    method = QUARTER_HOUR; 
	    fixedMinutes = 15;
	    }
        else if (strcmp(tempString,"5") == 0)
	    {
	    method = FIVE_MINUTES; 
	    fixedMinutes = 5;
	    }
        else if (strcmp(tempString,"1") == 0)
	    {
	    method = ONE_MINUTE; 
	    fixedMinutes = 1;
	    }
	else
	    {
	    method = TIME_SEGS;
	    timeFile = argv[3]; /*Should be name of time ("legs")file*/
	    fpTime = fopen (timeFile,"r");
	    if (fpTime == NULL)
		{
		fprintf(stderr, "\n%s: error on open of time file %s!!\n",prog,
		      timeFile);
	        exit(1);
		}
	    }
	if ((sscanf(argv[4],"%d",&filesToCopy) != 1) || (filesToCopy <1))
	    {
	    fprintf(stderr, "\n error on reading integer (tape files to copy)"
		"in run-string arg \"%s\"!!\n",argv[4]);
	    exit(1);
	    }

        if ((tempCharPtr=getenv("DEBUG")) !=NULL ) 
            {
            strncpy (tempString,tempCharPtr,TEMPSTRING_LEN -1);
            strtoupper (tempString);
            if (strcmp(tempString,"TRUE") == 0) 
                {
		DEBUG = TRUE;
                }
            else if (strcmp(tempString,"FALSE") == 0) 
                {
		DEBUG = FALSE;
                }
            else
                {
		/* leave as default */
                }
            }
	fprintf(stdout,"Program %s, last updated %s\n",
	     prog,sourcedate);

        if (DEBUG)
	    {
	    fprintf(stdout,"Tape to read: %s\n FlightID (dir): %s\n"
	    "Files to copy: %d\n"
	    "Maximum read errors(probably parity): %d\n"
	     ,tapeRead,flightID ,filesToCopy,unknownErrLimit);
	    if (method == FILES1_1)
	        fprintf(stdout,"Copy files one to one to disk.\n");
	    else if (method == QUARTER_HOUR)
	        fprintf(stdout,"create disk files every quarter hour.\n");
	    else if (method == FIVE_MINUTES)
	        fprintf(stdout,"create disk files every five minutes.\n");
	    else if (method == ONE_MINUTE)
	        fprintf(stdout,"create disk files every minute.\n");
	    else
	        fprintf(stdout,"create disk files according to times"
			" in file %s.\n",timeFile);
	    }
/*
 * Check that the flightID will be a new name.  If it isn't, ask
 * user whether to continue or not.
 */
	sprintf(unixCommand,"eval [ -d %s ]", flightID);
	systemStatus = system(unixCommand);
	if (systemStatus == 0)
	    {
/*
 * systemStatus == 0 means directory already exists.
 */
	    sprintf(tempString,"\nA subdirectory with the flightID name %s"
	       " ALREADY exits!\n"
	       "Do you want to continue?\n",flightID);
	    if (stdY_N(tempString,' ') == 'N')
		{
	        fprintf(stdout,"%s aborted!!\n"
	         	"Change flightID -OR- \n"
	         	"Move old flightID subdirectory -OR- \n"
	         	"Rerun and answer \"Y\" to continue.\n", argv[0]);
	        exit(1);
		}
	    }
	else
	    {
/*
 * No subdirectory with flightID name yet.  Try to make one!
 */
	    sprintf(unixCommand,"mkdir %s", flightID);
	    systemStatus = system(unixCommand);
	    if (systemStatus == 1)
		{
/*
 * systemStatus == 1 means we could not make the subdirectory!
 */
		fprintf(stdout,"%s aborted because attempt to make"
		    " subdirectory\n"
		    "with the unix command \"%s\" failed.\n"
			, argv[0],unixCommand);
		exit(1);
		}
	    }
	sprintf(tempString,"%s/p3tape_disk.list", flightID);
	nameList = NULL;
        mallocateAddString(&nameList,tempString);
	fpList = fopen (nameList,"w");
	if (fpList == NULL)
	    {
	    fprintf(stderr,"\nError on opening %s!\n ",
		nameList);
	    exit(1);
	    }

	timePt = &timeInternal;
	if (time (timePt)== -1)
	    {
	    strcpy (realTimeStart,"(*start time unavailable*)\n");
	    }
	else
	    {
	    strftime (realTimeStart,REALTIME_LEN-1,
	     "%a %b %d %H:%M:%S %Y %Z",gmtime(timePt)); 
	    }
	fprintf (stdout,"The start time is %s.\n",realTimeStart);
 
	if (method == TIME_SEGS)
	    {
	    timeStatus = readTimeFile(FIRST_OPEN_FILE,timeFile,
                 & boundaryDate,& boundaryTime);
	    if (timeStatus == T_ERROR)
		{
		fprintf(stderr, "\n%s: error on opening (or reading"
		" first date/time) in time file %s!\n"
		,prog, timeFile);
		exit(1);
		}
	    moreBoundaries = TRUE; /* TRUE if timeFile open and no EOF */
	    }

	fileDesTapeR = ioTapeOpen (tapeRead,ReadOnly);
	if (fileDesTapeR == -1)
	    {
	    fprintf(stderr, "\n%s: error on opening %s before copying!!\n"
	    ,prog, tapeRead);
	    exit(1);
	    }
/*
 * Now is the time to copy the files from tape to disk. 
 */
	keepReadingTape = TRUE;
	emptyFilesTotal=0;     /* count of Total EOF's skipped because empty*/
	recordsReadTotal = 0;  /* count of total records read */
	filesReadTotal = 0;    /* count of files read */
	filesCopiedTotal = 0;  /* count of disk files written; will be
				  incremented once another file is opened
				  for writing */
	recordsCopied = 0; /* records copied for file being written */
	recordsCopiedTotal = 0;  /* count of Total records copied */
	setsSeen = 0;  /* count of set-marks seen */
	biggestRecLen = 0;/* most bytes read/written in any record */
	bytesReadTotal = 0; /* long double count of Total bytes read */
	bytesCopiedTotal = 0; /* long double count of Total bytes copied,
				 not counting the logical record flag
				 lengths of 4 bytes (preceding & trailing
				 each logical record: 8 bytes/record )*/
/*
 * Although we're not counting set-marks for stopping purposes, still
 * count them.  Perhaps there won't be any, but when there are, we'll
 * let user know about them.
 */
	while (keepReadingTape && (filesReadTotal < filesToCopy))
	    {
	    keepReadingFile = TRUE;
	    recordsRead = 0; /* records read for file being read */
	    unknownErr = 0;  /* count of unknown tape errors in file(parity?) */
	    while (keepReadingFile && keepReadingTape)
		{
		status = ioTape(ReadRec,ioBuffer,MAX_REC_LEN,fileDesTapeR);
		if (status > 0)
		    {
		    recordsRead ++;
		    recordsReadTotal ++;
		    recLen = status;
		    bytesReadTotal += recLen;
		    recType = typeDateTime(ioBuffer,recLen,&thisDate,&thisTime);
		    if ((recType == TYPE_ERROR) 
		       || (recType == LENGTH_ERROR)
		       || (recType == DATE_ERROR))
			{
			errorRecordsSkipped ++;
			sprintf(tempString,"After copying %d record%s of file %d"
			 " the %d-th P3 tape record error\n"
			 "was encountered on %s.\n"
			 "This record will be skipped!!\n", recordsRead,
			 (recordsRead != 1) ? "s":"",
			 filesReadTotal,
			 errorRecordsSkipped,tapeRead);
			fprintf(stderr,"\n%s",tempString);
			logBufferAdd = strlen(tempString);
			if (logBufferAdd + logBufferEnd < LOGBUFFER_LEN)
			    {
			    strncpy(&logBuffer[logBufferEnd],
				 ioBuffer,logBufferAdd);
			    logBufferEnd += logBufferAdd;
			    }
			else
			    {
			    logBufferEnd = LOGBUFFER_LEN -1; /*buffer full*/
			    }
			}
		    else
			{

/*
* Before we write to disk file, check to see if we need a 
* new disk file (and therefore possibly close old disk file).
*/
			if ((recordsCopied == 0)
			   || ((method == FILES1_1) &&
			      (recordsRead <= 1)) 
			   || ((
			       ((method == QUARTER_HOUR) ||
			        (method == FIVE_MINUTES) ||
			        (method == ONE_MINUTE))) &&
			       (! NxTimeBefore(thisDate,thisTime,
					     endFixedTimePeriodDate,
					     endFixedTimePeriodTime)))
			   || ((method == TIME_SEGS) &&
			       (moreBoundaries) &&
			       (! NxTimeBefore(thisDate,thisTime,
					     boundaryDate,
					     boundaryTime))))
			    {
			    if (fpOut != NULL)
				{
				fclose(fpOut);
	                        fprintf(stdout,"%d records written to %s\n",
				    recordsCopied, nameOut);
				}

                            if (nameOutOld != NULL)
			        {
			        free(nameOutOld); /* clean up previous*/
			        }
			    nameOutOld = nameOut;
			    nameOut = NULL;
			    sprintf(tempString,"%s/%4.4d.%2.2d.%2.2d"
				 ".%2.2d%2.2d%2.2d",
				 flightID,
				 thisDate.year,thisDate.month,thisDate.day,
				 thisTime.hour, thisTime.minute,
				 thisTime.second);
			    mallocateAddString(&nameOut,tempString);
			    if ((nameOutOld != NULL) &&
                             (strncmp(nameOut,nameOutOld,strlen(nameOut))
				  == 0))
                                {
			        sprintf(tempString,".f%3.3d",
				   filesCopiedTotal+1);/*+1 because not ++ yet*/
				mallocateAddString(&nameOut,
				    tempString);/*unique!*/
				}
			    fpOut = fopen (nameOut,"w");
			    if (fpOut == NULL)
				{
				fprintf(stderr,"\nError on opening %s!\n ",
				    nameOut);
				exit(1);
				}
			    filesCopiedTotal ++;/*next disk file being written*/
			    recordsCopied = 0; /* for this new file */
	                    sprintf(tempString,"%s\n",nameOut);
	                    if (strlen(tempString) !=
	                                 fwrite(tempString,
		                        1,strlen(tempString),fpList))
		                {
				fprintf(stderr,"\nError on writing to"
				   "file with list of names%s!\n ",
				    nameList);
				exit(1);
				}
			    if (recType != HEADER_REC)
				{
				if (headerRecRead == TRUE)
				    {
				    if (! diskWrite(headerRec,
					      HEADER_LEN,
					      fpOut,
					      nameOut))
						
					exit(1);
				    extraHeadersCopied++;
				    bytesCopiedTotal += HEADER_LEN;
				    recordsCopied ++;
		                    recordsCopiedTotal ++;
				    }
				else
				    {
				    fprintf(stderr, "\nWARNING: no "
					    "starting header record for "
					    " %s! \n ", nameOut);
				    }
				}
			    if ((method == QUARTER_HOUR) ||
			        (method == FIVE_MINUTES) ||
			        (method == ONE_MINUTE))
				{
				endFixedTimePeriodDate.year = thisDate.year;
				endFixedTimePeriodDate.month = thisDate.month;
				endFixedTimePeriodDate.day = thisDate.day;
				endFixedTimePeriodTime.hour = thisTime.hour;
				endFixedTimePeriodTime.minute =
				    0;/*Will need to modify */
				addMinutes = 
				 (thisTime.minute /fixedMinutes)*fixedMinutes
				     + fixedMinutes ; /* to get to end 
					      of next time period */
				endFixedTimePeriodTime.second = 0;
				endFixedTimePeriodTime.milliSecond= 0;
				NxChangeTime(& endFixedTimePeriodDate,
					     & endFixedTimePeriodTime,
					     addMinutes); 
				}

/*
 * If we are looking at the times in a time file, try to get a date/time
 * that comes later than the current date.time.
 */
			    if (method == TIME_SEGS) 
			        while ((moreBoundaries) &&
			           (! NxTimeBefore(thisDate,thisTime,
					     boundaryDate,
					     boundaryTime)))
				    {
				    timeStatus = readTimeFile
					 (FILE_ALREADY_OPEN,timeFile,
					 & boundaryDate,& boundaryTime);
				    if (timeStatus == T_ERROR)
					{
					fprintf(stderr, "\n%s: error on reading"
					" date/time in time file %s!\n"
					,prog, timeFile);
					exit(1);
					}
				    else if (timeStatus == T_NO_MORE)
					moreBoundaries = FALSE; /* FALSE: 
						no more time boundaries*/
				    }
			    } /* * * * * end of code for new disk file */

			if (recType == HEADER_REC)
			    {
			    headerRecRead = TRUE;
			    memcpy(headerRec,ioBuffer,HEADER_LEN);
			    }
/*  
 * Should we care if it is LF_REC or TA_REC?
 */
			if (! diskWrite(ioBuffer,
				  recLen,
				  fpOut,
				  nameOut))
				    
			    exit(1);
			if (recLen > biggestRecLen)
			    biggestRecLen = recLen;/* most bytes read/written */
			bytesCopiedTotal += recLen;
			recordsCopied ++;
			recordsCopiedTotal ++;
			}
		    }
		else
		    {
/*  Here we were not able to read any bytes.  
 (1) If is was an unknown error, this is probably a parity error (but
 the information on whether it is parity is not available).  Increase count
 of unknown errors for this file and compare it to the limit to determine
 whether to continue reading from this file or aborting.
 (2) If it was EOF, then we can
 finish up this file copy by writing a logical EOF (unless no records and
 user does not want consecutive EOFs).
 (3) If it was a set-mark, then we can count and continue (don't
 consider it an EOF).
 (4) If it was not an EOF, not a set-mark, and not an unknown error,
 then we need to abort the copying.
 */
		    if (status == StatusUnknown)
			{
			unknownErr ++;
			sprintf(ioBuffer,"After copying %d record%s of file %d"
			 " the %d-th unknown tape error (probably parity)\n"
			 "was encountered on %s.\n", recordsRead,
			 (recordsRead != 1) ? "s":"",
			 filesReadTotal,
			 unknownErr,tapeRead);
			fprintf(stderr,"\n%s",ioBuffer);
			logBufferAdd = strlen(ioBuffer);
			if (logBufferAdd + logBufferEnd < LOGBUFFER_LEN)
			    {
			    strncpy(&logBuffer[logBufferEnd],
				 ioBuffer,logBufferAdd);
			    logBufferEnd += logBufferAdd;
			    }
			else
			    {
			    logBufferEnd = LOGBUFFER_LEN -1; /*buffer full*/
			    }
			if (unknownErr > unknownErrLimit)
			    {
			    keepReadingTape = FALSE;
			    keepReadingFile = FALSE;
			    fprintf(stderr,"Unknown-error-limit exceded: "
			    "Quit reading %s\n",tapeRead);
			    }
			}
		    else
			{
			keepReadingFile = FALSE;
			if ((status != StatusEOF)&&(status != StatusSET))
			    {
			    keepReadingTape = FALSE;
			    ioTapeStatus80(status,tempString);
			    sprintf(ioBuffer, "On reading %s status %s"
			    "\nTape reading terminated.\n"
			    ,tapeRead,tempString);
			    fprintf(stderr,"\n%s",ioBuffer);
			    logBufferAdd = strlen(ioBuffer);
			    if (logBufferAdd + logBufferEnd < LOGBUFFER_LEN)
				{
				strncpy(&logBuffer[logBufferEnd],
				     ioBuffer,logBufferAdd);
				logBufferEnd += logBufferAdd;
				}
			    else
				{
				logBufferEnd = LOGBUFFER_LEN -1; /*buffer full*/
				}
			    }
			}
		    if (status == StatusEOF)
			{
			filesReadTotal ++;
			keepReadingFile = FALSE;
			if ((recordsRead == 0) && 
			  ((! consecEOFs) || (fpOut == NULL)))
			    {
/*
 * Empty file and either user doesn't want to copy the EOF or
 * else no output file has been opened yet.
 */
			    emptyFilesTotal ++;
			    }
			else
			    {

/* Zero-byte record is logical EOF */
			    if (! diskWrite(headerRec,
					 0,
					 fpOut,
					 nameOut))
				 exit(1);

			    }
			sprintf(ioBuffer,"%d record%s read for file "
			       "%d.\n",recordsRead,
			       (recordsRead != 1) ? "s":"",
			       filesReadTotal);
			logBufferAdd = strlen(ioBuffer);
			if (logBufferAdd + logBufferEnd < LOGBUFFER_LEN)
			    {
			    strncpy(&logBuffer[logBufferEnd],
				 ioBuffer,logBufferAdd);
			    logBufferEnd += logBufferAdd;
			    }
			else
			    {
			    logBufferEnd = LOGBUFFER_LEN -1; /*buffer full*/
			    }
			fprintf(stdout,"%s",ioBuffer);
			}
		    if (status == StatusSET) 
			{
			setsSeen ++;
			}
		    } /* end of "if (status > 0) ... else " after ReadRec */
		}  /* end of "while (keepReadingFile ..." */
	    }  /* end of "while (keepReadingTape ..." */
        if (fpOut != NULL)
	    {
	    fclose(fpOut);
	    fprintf(stdout,"%d records written to %s\n",
				    recordsCopied, nameOut);
	    }
        close (fileDesTapeR);

	if (setsSeen >= 1)
            {
	    sprintf(tempString,";\n%d set-mark%s read"
                " but not copied.",setsSeen, (setsSeen != 1) ? "s were":" was");
            }
	else
	    sprintf(tempString,".");
	sprintf(ioBuffer,"\n******Copy Summary*****\n%d record%s "
		"(%L.0f = %LE bytes) from %d file%s\n"
		"%s copied to %d record%s"
		"(%L.0f = %LE bytes) in %d file%s%s\n"
	    ,recordsReadTotal,
	     (recordsReadTotal != 1) ? "s":"",
	    bytesReadTotal,bytesReadTotal,
	    filesReadTotal,
	     (filesReadTotal != 1) ? "s":"",
	     (recordsCopiedTotal != 1) ? " were":" was",
	    recordsCopiedTotal,
	     (recordsCopiedTotal != 1) ? "s":"",
	    bytesCopiedTotal,bytesCopiedTotal,
	    filesCopiedTotal,
	     (filesCopiedTotal != 1) ? "s":"",
	    tempString);
	logBufferAdd = strlen(ioBuffer);
	if (logBufferAdd + logBufferEnd < LOGBUFFER_LEN)
	    {
	    strncpy(&logBuffer[logBufferEnd],
		 ioBuffer,logBufferAdd);
	    logBufferEnd += logBufferAdd;
	    }
	else
	    {
	    logBufferEnd = LOGBUFFER_LEN -1; /*buffer full*/
	    }
	fprintf(stdout,"%s",ioBuffer);

	sprintf(ioBuffer,"The largest record copied was %d bytes long.\n"
	    ,biggestRecLen);
	logBufferAdd = strlen(ioBuffer);
	if (logBufferAdd + logBufferEnd < LOGBUFFER_LEN)
	    {
	    strncpy(&logBuffer[logBufferEnd],
		 ioBuffer,logBufferAdd);
	    logBufferEnd += logBufferAdd;
	    }
	else
	    {
	    logBufferEnd = LOGBUFFER_LEN -1; /*buffer full*/
	    }
	fprintf(stdout,"%s",ioBuffer);

	if (emptyFilesTotal >0)
	    {
	    sprintf(ioBuffer,"\nSpecial note: %d empty file%s skipped,\n"
	         "i.e., where there were EOF-s but no records.\n"
		, emptyFilesTotal,
		(emptyFilesTotal != 1) ? "s were":" was"
		);
	    logBufferAdd = strlen(ioBuffer);
	    if (logBufferAdd + logBufferEnd < LOGBUFFER_LEN)
		{
		strncpy(&logBuffer[logBufferEnd],
		     ioBuffer,logBufferAdd);
		logBufferEnd += logBufferAdd;
		}
	    else
		{
		logBufferEnd = LOGBUFFER_LEN -1; /*buffer full*/
		}
	    fprintf(stdout,"%s",ioBuffer);
	    }
	if (recordsCopiedTotal > 0)
	    {
	    sprintf(ioBuffer,"The last file %s\n"
	       "had the last date/time %4.4d.%2.2d.%2.2d"
		 ".%2.2d%2.2d%2.2d.%3.3d\n",
		 nameOut,
		 thisDate.year,thisDate.month,thisDate.day,
		 thisTime.hour, thisTime.minute,
		 thisTime.second, thisTime.milliSecond);

	    logBufferAdd = strlen(ioBuffer);
	    if (logBufferAdd + logBufferEnd < LOGBUFFER_LEN)
		{
		strncpy(&logBuffer[logBufferEnd],
		     ioBuffer,logBufferAdd);
		logBufferEnd += logBufferAdd;
		}
	    else
		{
		logBufferEnd = LOGBUFFER_LEN -1; /*buffer full*/
		}
	    fprintf(stdout,"%s",ioBuffer);
	    }
	if (biggestRecLen >= MAX_REC_LEN )
	    {
	    sprintf(ioBuffer,"\nWarning: the biggest record read was"
	    " at least as big as max size = %d.\n"
	         "It is suggested that you modify MAX_REC_LEN and run again. \n"
		,MAX_REC_LEN);
	    logBufferAdd = strlen(ioBuffer);
	    if (logBufferAdd + logBufferEnd < LOGBUFFER_LEN)
		{
		strncpy(&logBuffer[logBufferEnd],
		     ioBuffer,logBufferAdd);
		logBufferEnd += logBufferAdd;
		}
	    else
		{
		logBufferEnd = LOGBUFFER_LEN -1; /*buffer full*/
		}
	    fprintf(stdout,"%s",ioBuffer);
	    }

	timePt = &timeInternal;
	if (time (timePt)== -1)
	    {
	    strcpy (realTimeEnd,"(*end time unavailable*)\n");
	    }
	else
	    {
	    strftime (realTimeEnd,REALTIME_LEN-1,
	     "%a %b %d %H:%M:%S %Y %Z",gmtime(timePt)); 
	    }
	fprintf (stdout,"The program end time is %s.\n",realTimeEnd);
        exit(0);
} /* main of p3tape_disk ends */

/*
 * readTimeFile: read a date/time from the time file.
 * entry conditions:
 *   newFile: = TRUE to open up a new file (name: timeFile);
 *            = FALSE to use file previously opened (implicitly
 *              assumed to be timeFile);
 *   datePtr, timePtr: points to the date/time, undefined on entry.
 *
 * Each line of the date/time file should like 
 *            "1999/03/31 041200"
 * i.e., YYYY/MM/DD HHMMSS
 *
 * return value is one of the enum timeFileReading values:
 *   T_ERROR: an error in opening the file or in trying to
 *     read the date/time, or if the date/time is bad, or if
 *     this is not a newly opened file and the previously read
 *     date/time comes before the just read date/time
 *     (datePtr, timePtr will be undefined; timeFile will be closed);
 *   T_OK_DATE: date/time read and returned in * datePtr,NxTime * timePtr;
 *          timeFile will remain opened.
 *   T_NO_MORE: EOF read in the file (datePtr, timePtr will be undefined;
 *          timeFile will be closed);
 */
int readTimeFile(int newFile,char timeFile[],
                 NxDate * datePtr,NxTime * timePtr)

{
#define   LINELENGTH  142     /*Undefine at end of this module */
    
    char  module[] = "readTimeFile";
    char  lineBuffer[LINELENGTH]; /* buffer to contain line read in */
    char  ignore = '!';      /* character to signal ignore rest of line read*/
    int   year,month,day,
          hour,minute,second;
    int   milliSecond = 0; /* not read so just put in filler */      
    static lineNum = 0;
    static FILE  *fp = NULL;/*file pointer, for reading the file*/
    static NxDate  dateOld;
    static NxTime  timeOld;

    if (newFile)
        {
	fp = fopen (timeFile,"r");
	if (fp == NULL)
	    {
            fprintf(stderr, "\n%s: error on open of %s!!\n",module,
		  timeFile);
	    return T_ERROR;
	    }
        }
    else if (fp == NULL)
	    {
            fprintf(stderr, "\n%s: programming error--reading"
                   " before opening of %s!!\n",module, timeFile);
	    return T_ERROR;
	    }
    if (fgets(lineBuffer,LINELENGTH -1 ,fp) == NULL)
        {
        fclose(fp);
        if (! newFile)
            return T_NO_MORE;        /*EOF (or could be error) on reading */
        else
	    {
/*
 * We expect a file to contain at least one date/time line.
 */
            fprintf(stderr,"\n%s: error on reading first line of %s!!\n",module,
		  timeFile);
	    return T_ERROR;
	    }
        }

    if (DEBUG)
        fprintf (stdout,"In module %s line read was \n>>%s",
                 module,lineBuffer);
    lineNum ++;
 /*    if (sscanf(lineBuffer,"%4.4d/%2.2d/%2.2d %2.2d%2.2d%2.2d", */
    if (sscanf(lineBuffer,"%4d/%2d/%2d %2d%2d%2d",
            &year, &month, &day, &hour,&minute,&second)  != 6)
        {
        fprintf (stderr,"In module %s line %d of time file\n>>%s"
            "could not be read for \"YYYY/MM/DD HHMMSS\".\n",
         module,lineNum,lineBuffer);
        fclose(fp);
	return T_ERROR;
        }
    datePtr->year = year;
    datePtr->month = month;
    datePtr->day = day;
    timePtr->hour = hour;
    timePtr->minute = minute;
    timePtr->second = second;
    timePtr->milliSecond = milliSecond;
    if ( ! NxOkTime(*datePtr,*timePtr))
        {

        fprintf (stderr,"In module %s line %d of time file\n>>%s"
            "could not be read for valid date/time \"YYYY/MM/DD HHMMSS\".\n",
         module,lineNum,lineBuffer);
        fclose(fp);
	return T_ERROR;
        }
    if ((! newFile) && ( ! NxTimeBefore(dateOld,timeOld,*datePtr,*timePtr)))
        {

        fprintf (stderr,"In module %s in line %d of time file\n>>%s"
            "the date/time did not come after the previously read"
            " date/time\n%4.4d/%2.2d/%2.2d %2.2d%2.2d%2.2d!!\n",
         module,lineNum,lineBuffer,dateOld.year,dateOld.month,dateOld.day,
         timeOld.hour,timeOld.minute,timeOld.second);
        fclose(fp);
	return T_ERROR;
        }
    dateOld.year = year;
    dateOld.month = month;
    dateOld.day = day;
    timeOld.hour = hour;
    timeOld.minute = minute;
    timeOld.second = second;
    timeOld.milliSecond = milliSecond;
    return T_OK_DATE;
#undef   LINELENGTH 
}  /* int readTimeFile ends */

/*
 * typeDateTime: get date/time and record type from the character buffer
 * which contains a P3 tape header record or a P3 data record.
 * entry conditions:
 *       ioBuffer: buffer with bytes read in;
 *       recLen: bytes in ioBuffer;
 *   datePtr, timePtr: points to the date/time, undefined on entry.
 *
 * For the following "ERROR returns", a message will be written to stderr.
 *
 * return value is one of the enum typeP3 values:
 *   TYPE_ERROR: an error in record type (neither P3 Header record
 *     type or P3 data record) (16-bit word one)
 *     (datePtr, timePtr will be undefined);
 *   LENGTH_ERROR: an error in record length, as recLen does not equal
 *     the value stored in the "record length" (16-bit word two)
 *     (datePtr, timePtr will be undefined);
 *   DATE_ERROR: a bad date/time was read
 *     (datePtr, timePtr will be undefined);
 *   HEADER_REC: header record  (datePtr, timePtr will point to
 *     the date/time).
 *   LF_REC: lower fuselage radar data record  (datePtr, timePtr will point to
 *     the date/time).
 *   TA_REC: tail radar data record  (datePtr, timePtr will point to
 *     the date/time).
 *
 ******* Warning: the character buffer, seen as containing 16-bit words,
 * should NOT have the characters swapped, even if
 * if this is running on a LittleEndian (Lo-Hi) machine. The P3 data
 * is written on tape in HiLo format.  The conversion to Lo-Hi integers
 * will be handled by the packSInt function.
 */
int  typeDateTime(char ioBuffer[],int recLen,NxDate * datePtr,
       NxTime * timePtr)
{
    const int WORDBYTES=2;    /* 2 bytes per 16-bit word */
    const int TO_LOW_BYTE=1;  /* Skip 1 byte in 16-bit word to get to low byte*/
    const int HEADER_TYPE=0;  /* header record type (word 1) is 0 */
    const int DATA_TYPE=1;    /* data type (word 1) is 1 */
    const int LF_TYPE=1;      /* high byte data record word 5 is 1 for LF */
    const int TA_TYPE=2;      /* high byte data record word 5 is 2 for TA */
    const int HiLo = 0;       /* Defined for "swap" in function packSInt */
    const int numPack=1;      /* Used in function packSInt: number of
                                 short ints to pack/unpack */
    int       wordNumber;     /* 16bit word number in buffer: starting at 1 */
    int       swap;           /* Used in function packSInt */
    int       radarType;
    short int recordType;
    short int recordLength;
    short int shortI;         /* temp short int */
    short int year,month,day, /* short int to go with packSInt */
              hour,minute,
              second,milliSecond;
    char  module[]="typeDateTime";


    swap = HiLo;             /* for Hi-Lo "swap" in function packSInt */
    wordNumber = 1;
    packSInt(ioBuffer + (WORDBYTES * (wordNumber -1)),
                      &recordType,numPack,swap);          /* word 1 */
    if ((recordType != HEADER_TYPE) && (recordType != DATA_TYPE))
        {
        fprintf(stderr, "In module %s P3 record type (word 1) should be"
           " %d or %d,\nbut value read was %d!!\n",
           module,HEADER_TYPE,DATA_TYPE,recordType);
        return TYPE_ERROR;
        }

    wordNumber = 2;
    packSInt(ioBuffer + (WORDBYTES * (wordNumber -1)),
                      &recordLength,numPack,swap);        /* word 2 */
    if (recordLength != recLen)
        {
        fprintf(stderr, "In module %s P3 record length was %d bytes "
           "but word 2 = %d\n", module, recLen, recordLength);
        return LENGTH_ERROR;
        }

    if (recordType == HEADER_TYPE)
        {
/*
 * Get date/time from header record.
 */
        wordNumber = 6;
        packSInt(ioBuffer + (WORDBYTES * (wordNumber -1)), /* YY */
                      &year,numPack,swap);                 /* word 6 */
	year = NxFullYear(year);            /* convert YY to YYYY */
        wordNumber = 7;
        packSInt(ioBuffer + (WORDBYTES * (wordNumber -1)), /* month */
                      &month,numPack,swap);                /* word 7 */
        wordNumber = 8;
        packSInt(ioBuffer + (WORDBYTES * (wordNumber -1)), /* day */
                      &day,numPack,swap);                  /* word 8 */
        wordNumber = 9;
        packSInt(ioBuffer + (WORDBYTES * (wordNumber -1)), /* hour */
                      &hour,numPack,swap);                 /* word 9 */
        wordNumber = 10;
        packSInt(ioBuffer + (WORDBYTES * (wordNumber -1)), /* minute */
                      &minute,numPack,swap);               /* word 10 */
        wordNumber = 11;
        packSInt(ioBuffer + (WORDBYTES * (wordNumber -1)), /* second */
                      &second,numPack,swap);               /* word 11 */
        milliSecond = 0;   /* not contained in header record */
        }
    else
        {
/*
 * Get date/time from data record.
 */
        wordNumber = 5;
	radarType = (unsigned char) *(ioBuffer +           /* radar type */
	   (WORDBYTES * (wordNumber -1)));               /* word 5,hiByte */
        wordNumber = 7;
	year = (unsigned char) *(ioBuffer +                /* YY */
	   (WORDBYTES * (wordNumber -1) + TO_LOW_BYTE)); /* word 5+2,lowByte */
	year = NxFullYear(year); /* convert YY to YYYY */
        wordNumber = 8;
	month = (unsigned char) *(ioBuffer +               /* month */
	   (WORDBYTES * (wordNumber -1)));               /* word 5+3,hiByte */
        wordNumber = 8;
	day = (unsigned char) *(ioBuffer +                 /* day */
	   (WORDBYTES * (wordNumber -1) + TO_LOW_BYTE)); /* word 5+3,lowByte */
        wordNumber = 9;
	hour = (unsigned char) *(ioBuffer +                /* hour */
	   (WORDBYTES * (wordNumber -1) + TO_LOW_BYTE)); /* word 5+4,lowByte */
        wordNumber = 10;
        packSInt(ioBuffer + (WORDBYTES * (wordNumber -1)), 
                      &minute,numPack,swap);          /* word 5+5: minutes */
        wordNumber = 11;
        packSInt(ioBuffer + (WORDBYTES * (wordNumber -1)),
                      &shortI,numPack,swap);          /* word 5+6: secs X 100 */
        second = shortI/100;
        milliSecond = 10*(shortI % 100); 
        }

    datePtr->year = year;
    datePtr->month = month;
    datePtr->day = day;
    timePtr->hour = hour;
    timePtr->minute = minute;
    timePtr->second = second;
    timePtr->milliSecond = milliSecond;
    if ( ! NxOkTime(*datePtr,*timePtr))
        {

        fprintf (stderr,"In module %s "
            "there was invalid date/time"
            " %4.4d/%2.2d/%2.2d %2.2d%2.2d%2.2d!!\n",
        module,year,month,day,hour,minute,second);
	return DATE_ERROR;
        }

    if (recordType == HEADER_TYPE)
	return HEADER_REC;
    if (radarType == LF_TYPE)
	return LF_REC;
    else if (radarType == TA_TYPE)
	return TA_REC;
    else
        {
        fprintf(stderr, "In module %s P3 record type"
	   " (data record word 5, high byte)\nshould be"
           " %d or %d, but value read was %d!!\n",
           module,LF_TYPE,TA_TYPE,radarType);
        return TYPE_ERROR;
        }
} /* int typeDateTime ends */

/*
 * diskWrite: write disk record with the 4-byte "logical record length"
 *   before and after.
 *
 * entry conditions:
 *    buffer: buffer to write;
 *    bytesToWrite: >= 0; {0 for logical EOF}
 *    fp: FILE pointer;
 *    fileName: name of file (for error messages)
 * 
 * return:
 *   TRUE if writes went OK.
 *   FALSE if problems (and message will be written to stderr)
 */
int diskWrite(char buffer[], int bytesToWrite,FILE * fp,char fileName[])
{
    const int FOUR=4;
    int   count;
    static int firstTime=TRUE;
    const int BYTE_SIZE=1;  /* have byte as the unit */
    int bytesWritten;

    char  fourBytes[4];
    char  module[]="diskWrite";

    if (firstTime)
        {
/*
 * We also need "count" (an "int") to be four-bytes long in order to write the
 * 4-byte logical record length.
 */
	if (sizeof (int) != FOUR)
	    {
	    fprintf(stderr,"\nProgramming trouble in module %s!\n"
	    "Sizeof int needs to be %d but instead is %d.\n"
	    ,module, FOUR, sizeof (int));
	    return FALSE;
            }
        firstTime = FALSE;
        }

    if (bytesToWrite < 0)
        return FALSE;
       
    count = bytesToWrite;

    bytesWritten = fwrite(& count ,
	      BYTE_SIZE,FOUR,fp);       /* leading 4-byte length flag */
    if (bytesWritten != FOUR)
	{
	fprintf(stderr, "\nError on writing"
	    " %d bytes to %s! \n ",
	    FOUR,fileName);
        return FALSE;
	}

    if (bytesToWrite > 0)
        {
	bytesWritten = fwrite(buffer,
		  BYTE_SIZE,bytesToWrite,fp);
	if (bytesWritten != bytesToWrite)
	    {
	    fprintf(stderr, "\nError on writing"
		" record of %d bytes to %s! \n ",
		bytesToWrite,fileName);
	    return FALSE;
	    }
	}

    bytesWritten = fwrite(& count ,
	      BYTE_SIZE,FOUR,fp);       /* trailing 4-byte length flag */
    if (bytesWritten != FOUR)
	{
	fprintf(stderr, "\nError on writing"
	    " %d bytes to %s! \n ",
	    FOUR,fileName);
        return FALSE;
	}
    return TRUE;
} /* int diskWrite ends */



/*
 * mallocateAddString: malloc for a given string and the addon string (keeping
 *     the addon string as is, i.e., no trimming of trailing blanks)
 *     and create this new string.
 *     Change string pointer to point to newly created string.
 *     The space in the original string is freed unless it was null.
 *     Return length of new string (number of characters in string
 *     excluding the \0 byte at the end).
 *     This module will work ok if either *stringPtr or addString
 *     = NULL; though note in the case both = NULL, then
 *     on exit *stringPtr will still be NULL.
 * Abort if trouble with malloc.
 */
int  mallocateAddString(char ** stringPtr, char * addString)
{
#define FUNCTION_NAME "mallocateAddString"
    char * charPtr;
    int    lengthString, lengthAddString;

    charPtr = * stringPtr;   /* save so we can free up original string at end*/
    if (*stringPtr == NULL)
        lengthString = 0;
    else
        lengthString = strlen(*stringPtr);
    if (addString == NULL)
        lengthAddString = 0;
    else
        lengthAddString = strlen(addString); 
    if (lengthAddString == 0)
	return (lengthString);     /* nothing to add */
    if ((*stringPtr = (char *)malloc (1 + lengthString +
		       lengthAddString))==NULL)
	{
	fprintf(stderr,"Malloc trouble in function %s with strings\n"
		       "%s\nand\n%s\n",FUNCTION_NAME,
		       *stringPtr,addString);
	exit (1);
	}
     if (charPtr == NULL)
         *stringPtr[0]= '\0';
     else
         strcpy(*stringPtr,charPtr);    /* copy over the original string */
     strcpy(*stringPtr + lengthString,addString); 
     if (lengthString > 0)
	 free(charPtr);
    return (lengthString + lengthAddString);

#undef FUNCTION_NAME
} /* int  mallocateAddString ends*/



/****************************  NxFullYear  **********************************
 * Adjust an integer year into a form which contains the century (2 or 3
 * digit year into 4 digits).  This routine returns the converted year.
 *
 * Use: for programs where Year is sometimes in form YY or even worse 
 * YYYY-1900 (which would be 101 for the year 2001).  Function fullYear
 * converts to YYYY which is between 1900 + YEAR_CUTOFF and 2100.  
 * If year is YYYY then leave as is.
 * This module will abort if (1) year <0;
 * 		             (2) year >= 200 and < 1900;
 *                           (3) year >=2100
*****************************************************************************/
int NxFullYear (int year)
{
    if ( (year <0) ||
	((year >= 200) && (year < 1900)) ||
	 (year >= 2100))
	{
	fprintf(stderr, "year passed to NxFullYear is out of range: %d\n",
	       year);
	exit(1);
	}
    else if (year < NX_YEAR_CUTOFF )
        return (year + 2000);
    else if (year < 200)
        return (year + 1900);
    return (year);
} /* int NxFullYear ends */




/* 
 * NxOkTime:
 *   check that the date/time are acceptable.
 *   Years before 1800 are not acceptable.
 *   Return 1 if acceptable, 0 if not.
 */
short int NxOkTime (NxDate date, NxTime time)
{
    
    short int idays[12] = {31,28,31,30,31,30,31,31,30,31,30,31};
    short int days;

    if ((date.year < 1800) || (date.month < 1) || (date.month >12))
	return 0;                     /* out of range!! */
    days = idays[date.month - 1];     /* get number of days in month */
    if ((date.month ==2) && (date.year%4 ==0)&& 
	 ((date.year%100 !=0) || (date.year%400 ==0))) 
	days = 29; /*leap year every 4 y. except centuries not divis by 400 */
    if ((date.day < 1) || ((int) date.day > days) ||
	(time.hour < 0) || (time.hour > 23) ||
	(time.minute < 0) || (time.minute > 59) ||
	(time.second < 0) || (time.second > 59) ||
	(time.milliSecond < 0) || (time.milliSecond > 999))
	return 0;
    return 1;
}
/* NxOkTime ends */


/*
 NxChangeTime: change the time/date by "change" minutes.
 The maximum magnitude of "change" is 1440= 24X60, i.e., one day.
 The date/time passed to this function are not checked for
 out-of-range values.
 Example: you have time 60 minutes ahead of UTC and you want to
 convert to UTC.  Call with change = -60. (e.g., this would change
 11 o'clock to 10 o'clock).
 */
void NxChangeTime (NxDate *date,NxTime *time,short int change)
{
    short int minutes,hours,days;
    char module[]= "NxChangeTime"; 
    short int maxMinutes = 1440;
    short int idays[12] = {31,28,31,30,31,30,31,31,30,31,30,31};

    if ((change < - maxMinutes) || (change > maxMinutes))
	NxAbort(NX_FATAL,module,"out-of-range minutes-to-change");

/* Use temporay minutes bacause time->minute may not be large enough
 * to hold "change".
 */
    minutes = time->minute + change;

    if (minutes <0)
	hours = -((59-minutes)/60);
    else
	hours = minutes/60;
    time->minute = minutes - 60*hours;
    if (hours == 0)
	return;         /* No hour or larger unit change */
    
    hours += time->hour;
    if (hours < 0)
	days = -((23-hours)/24);
    else
	days = hours/24;
    time->hour = hours - 24*days;
    if (days == 0)
	return;         /* No day or larger unit change */
    
    date->day += days;
    days = idays[date->month - 1];     /* get number of days in month */
    if ((date->month ==2) && (date->year%4 ==0)&& 
	 ((date->year%100 !=0) || (date->year%400 ==0))) 
	days = 29; /*leap year every 4 y. except centuries not divis by 400 */
    if ((1 <=date->day) && ((int) date->day <= days))
	return;              /* day is within range so no month/year change */

    if (date->day < 1)
	{
	date->month =((int) date->month + 10)%12 + 1;/*forward 11 = backward 1*/
	date->day = idays[date->month - 1];
	if ((date->month ==2) && (date->year%4 ==0)&& 
	     ((date->year%100 !=0) || (date->year%400 ==0))) 
	    date->day = 29; /*leap year */
	else if (date->month == 12)
	    date->year -= 1;
	}
    else
	{
	date->month = date->month%12 + 1;
	date->day = 1;
	if (date->month ==1)
	    date->year++;
	}

    return;
}
/* NxChangeTime ends */





/*
 * packSInt: take bytes from character buffer and pack, two bytes per integer,
 *         into a short int array.
 * Input conditions:
 *     bufpt: points to character buffer (although contents are probably
 *       not character data) which will be read for two bytes each time
 *       another short integer is needed.
 *     SInt: short integer array, to which the bytes will be packed.
 *     count: number of integers to pack into SInt.
 *     swap: =0 for HiLo (=BigEndian) storage in character buffer.
 *           =1 for LoHi (=LittleEndian) storage in character buffer.
 */
void packSInt (char *bufpt,short int SInt[],int count, int swap)
{
    /* hi and lo need to be signed and unsigned in case a short int
     * is longer than 2 bytes.
     */
    signed char hi;
    unsigned char lo;
    int i;

    if (swap)
        for (i=0; i < count; i++)
	{
	    lo=*(bufpt++);                /* LoHi = LittleEndian */
	    hi=*(bufpt++);
	    SInt[i] =(((short int)(hi))<<8) | lo;
	}
    else
        for (i=0; i < count; i++)
	{
	    hi=*(bufpt++);                /* HiLo = BigEndian */
	    lo=*(bufpt++);
	    SInt[i] =(((short int)(hi))<<8) | lo;
	}
    return;
}/* packSInt ends */


/*
 * NxTimeBefore
 *   checks if first date/time occurs before 2nd date/time.
 *   Return 1 if  before, 0 if first pair occurs same time or later.
 *   No checking is made for out-of-range values;
 */
short int NxTimeBefore (NxDate date1, NxTime time1, NxDate date2, NxTime time2)
{
    if (date1.year < date2.year)
	return 1;                /* date 1 before date 2 */
    else if (date1.year > date2.year)
	return 0;                /* date 1 after date 2 */

    if (date1.month < date2.month)
	return 1;                /* date 1 before date 2 */
    else if (date1.month > date2.month)
	return 0;                /* date 1 after date 2 */

    if (date1.day < date2.day)
	return 1;                /* date 1 before date 2 */
    else if (date1.day > date2.day)
	return 0;                /* date 1 after date 2 */

    if (time1.hour < time2.hour)
	return 1;                /* date 1 before date 2 */
    else if (time1.hour > time2.hour)
	return 0;                /* date 1 after date 2 */

    if (time1.minute < time2.minute)
	return 1;                /* date 1 before date 2 */
    else if (time1.minute > time2.minute)
	return 0;                /* date 1 after date 2 */

    if (time1.second < time2.second)
	return 1;                /* date 1 before date 2 */
    else if (time1.second > time2.second)
	return 0;                /* date 1 after date 2 */

    if (time1.milliSecond < time2.milliSecond)
	return 1;                /* date 1 before date 2 */
    else if (time1.milliSecond > time2.milliSecond)
	return 0;                /* date 1 after date 2 */

    return 0;                /* date 1 same as (="not before") date 2 */
}
/* NxTimeBefore ends */



/************************************************************************
 *  strtoupper()							*
 * convert a string to upper case                                       *
 ************************************************************************/
char *strtoupper (char *string)
{
    char *temp;

    temp = string;

    while (*temp != '\0')
    {
	*temp = (char) toupper (*temp);
	temp++;
    }

    return (string);
}/* strtoupper ends */


/*
 * stdY_N
 * Get user input from stdin for 'y'='Y' or 'n'='N' (stdout is used to
 * communicate with the user).  The user must hit the <cr> to enter answer.
 * The answer will be returned upper case.
 * If the default is 'y'='Y' or 'n'='N', and if the
 * user only enters <cr>, i.e., '\n', then the default
 * will be used.  The user will know of default because "(Y)" or "(N)"
 * will be appended to the question string passed to this module.
 * If the user enters USERIN_LEN characters or more, then ABORT.
 *Input
 *   question: points to the string which be printed to stdout, e.g.,
	  "\nDo you want READ ONLY?"
 *   the_default: casefolded is 'Y' or 'N', otherwise ignored.
 *Return value: either 'Y' or 'N'.
 *NOTE: if the code accessed before this routine had a "scanf" call,
 *  then there will probably be remnants in the buffer (the remnant could
 *  be a '\n' which would make this routine return a default because
 *  it seems that the user entered it in response to the question).  To
 *  flush this buffer the calling module probably needs to do
 *       gets(userIn);
 *  to clear the buffer.
 */
char stdY_N (char *question,char the_default)
{
#define     USERIN_LEN  30 /* maximum length to read */
    char    quesAdd[]="(y/n){ }";/*Used to add on the default to the question */
    char    answer;
    char    userIn[USERIN_LEN];

    the_default = toupper((int) the_default);
    if  ((the_default != 'Y') && (the_default != 'N'))
	{
	the_default = ' ';
	*(quesAdd+5) = '\0'; /* ignore end of string, so we have
			   quesAdd = "(y/n)";  i.e., no addon for the_default */
	}
    else
	{
	*(quesAdd+6) = the_default; /* put default between { } */
	}
    answer = '?';
    while  ((answer != 'Y') && (answer != 'N'))
	{
	fprintf(stdout, "%s%s ",question,quesAdd);
	gets(userIn);
	if ((int) strlen(userIn) >=  USERIN_LEN)
	    {
	    fprintf(stderr, "\n!! Abort in stdY_N because user input"
		" too many characters(%i>=%i)!!\n",strlen(userIn),USERIN_LEN);
	    exit (1);
	    }
	answer = userIn[0];    /* We only care about the first character */
	if (answer == '\0')    /* module "gets" converts \n into \0 */
	    answer = the_default;  /* Default input, since user just did <CR> */
	answer = toupper((int) answer);
	}
    return answer;
#undef     USERIN_LEN  /* only use locally */
} /* stdY_N ends */



/*
 * Module NxAbort
 *  Print error message and exit with abortNumber
 */
void   NxAbort (int abortNumber,char * module,char * message)
{
    fprintf(stderr,"\nModule %s reported fatal-error %d with message %s\n",
	module, abortNumber, message);
    exit (abortNumber);
} /* void   NxAbort ends */
